<?php


use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Dbm_CmsLayouts',
    __DIR__
);
