<?php


namespace Dbm\CmsLayouts\Block\Adminhtml\Layouts;

/**
 * Class Grid
 * @package Dbm\CmsLayouts\Block\Adminhtml\Layouts
 */
class Grid extends \Magento\Backend\Block\Widget\Grid
{
}
