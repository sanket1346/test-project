<?php

namespace Dbm\CmsLayouts\Block\Adminhtml\Cms;

/**
 * Class Grid
 * @package Dbm\CmsLayouts\Block\Adminhtml\Cms
 */
class Grid extends \Magento\Backend\Block\Widget\Grid
{
}
