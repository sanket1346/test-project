<?php

namespace Dbm\CmsLayouts\Controller\Adminhtml\Layouts;

/**
 * Class CmssGrid
 * @package Dbm\CmsLayouts\Controller\Adminhtml\Layouts
 */
class CmssGrid extends Cmss
{
}
