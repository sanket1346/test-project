var config = {
	paths: {
		custom: 'Dbm_CmsLayouts/js/custom',	},
	shim: {
		custom: {
			deps: ['jquery']
		},
	}
};
