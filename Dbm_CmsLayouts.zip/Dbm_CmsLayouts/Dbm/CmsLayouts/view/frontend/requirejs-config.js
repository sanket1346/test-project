var config = {
    map: {
        '*': {
            	owlcarousel:'Dbm_CmsLayouts/js/owl.carousel.min'
        	}
    	},
    shim: {
        'owlcarousel': {
            deps: ['jquery']
        }
    }
};
